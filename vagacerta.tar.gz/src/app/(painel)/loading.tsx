import { Carregamento } from "@/components/carregamento";

export default function ACarregar() {
  return <Carregamento />;
}
