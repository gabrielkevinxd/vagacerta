import { register } from "node:module";
import { pathToFileURL } from "node:url";

register("vite-tsconfig-paths/vite", pathToFileURL("./"));
